
const Discord = require('discord.js');
const path = require('path')
const client = new Discord.Client();
const AntiSpam = require('discord-anti-spam');


client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
  if (msg.content === '+hello') {
    msg.reply("Hello!");
  }
});

client.on('message', msg => {
  if (msg.content === "+flipacoin") {
    var headsortails = Math.floor(Math.random() * 2)
    if (headsortails == 0){
      msg.reply("You got Heads")
    }
    else{
      msg.reply("You got Tails")
    }

  }
});



client.on('message', msg => {
  if (msg.content === "+about") {
    const aboutbbot = new Discord.MessageEmbed()
    .setColor('#000DFF')
    .setTitle('About BoeingBot Open Source')
    .setDescription('BoeingBot Open Source is the open source version of BoeingBot Pro.')
    .setThumbnail('https://cdn.discordapp.com/attachments/788570535021903915/794692952621449236/images.jpg')
    .addFields(
      {name: 'Version', value: 'Version 1.0.0'},
      {name: 'Version', value: '19438A'},
      {name: 'Creator', value: 'A project by Firey Incorporated'},
      {name: 'Software Used', value: 'Made using node.js and discord.js'}
    )
    .setFooter('2021 Firey Inc/2021 BoeingBot Foundation')
    .setTimestamp()

    msg.channel.send(aboutbbot)

    
  }
});
const prefix = '+';

client.on('message', message => {
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.trim().split(/\s*(?:;|$)\s*/);
  const cmd = args[0].slice(prefix.length).toLowerCase(); // case INsensitive, without prefix

  if (cmd === 'poll') {
    const polls = new Discord.MessageEmbed()
    .setColor('#000DFF')
    .setTitle(`${args[1]}`)
    .addFields(
      {name: '1️⃣ Option 1', value: `${args[2]}`},
      {name: '2️⃣ Option 2', value: `${args[3]}`}
    )
    .setFooter(`Requested by @${message.author.username}`) 
    .setTimestamp() 
    
    message.channel.send(polls).then(sentEmbed => {
      sentEmbed.react('1️⃣')
      sentEmbed.react('2️⃣')
    })
      
  }
});

client.on('message', msg => {
  if (msg.content === "+rulespoll") {
    const polls = new Discord.MessageEmbed()
    .setColor('#000DFF')
    .setTitle(`Did you read the rules?`)
    .addFields(
      {name: '1️⃣ Option 1', value: `I read the rules!`},
      {name: '2️⃣ Option 2', value: `I did not read them.`}
    )
    .setFooter(`Requested by @${msg.author.username}`) 
    .setTimestamp() 
    
    msg.channel.send(polls).then(sentEmbed => {
      sentEmbed.react('1️⃣')
      sentEmbed.react('2️⃣')
    })
  }
});
client.on('message', msg => {
  if (msg.content === "+boeing707") {
    const aboutbbot = new Discord.MessageEmbed()
    .setColor('#000DFF')
    .setTitle("Boeing707")
    .setImage('https://cdn.discordapp.com/attachments/788117474449031218/788487832611323904/maxresdefault.jpg')
    
    
    msg.channel.send(aboutbbot)

    
  }
});
client.on('message', message => {
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.trim().split(/\s*(?:;|$)\s*/);
  const cmd = args[0].slice(prefix.length).toLowerCase(); // case INsensitive, without prefix

  if (cmd === 'poll') {
      
  }
});
client.on('message', message => {
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.trim().split(/ +/g);
  const cmd = args[0].slice(prefix.length).toLowerCase(); // case INsensitive, without prefix

  if (cmd === 'win95kg') {
    if (args[1] == 'retail'){
      var keytail = Math.floor(Math.random() * 999)+100;
      var key1 = Math.floor(Math.random() * 10);
      var key2 = Math.floor(Math.random() * 10);
      var key3 = Math.floor(Math.random() * 10);
      var key4 = Math.floor(Math.random() * 10);
      var key5 = Math.floor(Math.random() * 10);
      var key6 = Math.floor(Math.random() * 10);
      var key7 = Math.floor(Math.random() * 10);
      var mathvar = key1+key2+key3+key4+key5+key6+key7
      mathvar = mathvar%7
      while (mathvar>0){
        var keytail = Math.floor(Math.random() * 999)+100;
        var key1 = Math.floor(Math.random() * 10);
        var key2 = Math.floor(Math.random() * 10);
        var key3 = Math.floor(Math.random() * 10);
        var key4 = Math.floor(Math.random() * 10);
        var key5 = Math.floor(Math.random() * 10);
        var key6 = Math.floor(Math.random() * 10);
        var key7 = Math.floor(Math.random() * 10);
        var mathvar = key1+key2+key3+key4+key5+key6+key7
        mathvar = mathvar%7
      }
      if (mathvar == 0){
      
        var fullkey = `${keytail}-${key1}${key2}${key3}${key4}${key5}${key6}${key7}`
        message.channel.send(`Your key is: ${fullkey}`);
      }
    }  

      if (args[1] == 'oem'){
        var keytail = Math.floor(Math.random() * 366)+100;
        var keytail2 = Math.floor(Math.random() * 99)+95;
        var key1 = Math.floor(Math.random() * 10);
        var key2 = Math.floor(Math.random() * 10);
        var key3 = Math.floor(Math.random() * 10);
        var key4 = Math.floor(Math.random() * 10);
        var key5 = Math.floor(Math.random() * 10);
        var key6 = Math.floor(Math.random() * 10);
        var foot = Math.floor(Math.random() * 99999)+10000;
        var mathvar = key1+key2+key3+key4+key5+key6+0
        mathvar = mathvar%7
        while (mathvar>0){
          var keytail = Math.floor(Math.random() * 366)+100;
          var keytail2 = Math.floor(Math.random() * 99)+95;
          var key1 = Math.floor(Math.random() * 10);
          var key2 = Math.floor(Math.random() * 10);
          var key3 = Math.floor(Math.random() * 10);
          var key4 = Math.floor(Math.random() * 10);
          var key5 = Math.floor(Math.random() * 10);
          var key6 = Math.floor(Math.random() * 10);
          var foot = Math.floor(Math.random() * 99999)+10000;
          var mathvar = key1+key2+key3+key4+key5+key6+0
          mathvar = mathvar%7
        }
        if (mathvar == 0){
      
          var fullkey = `${keytail}${keytail2}-OEM-0${key1}${key2}${key3}${key4}${key5}${key6}-${foot}`
          message.channel.send(`Your key is: ${fullkey}`);
        }
    }
    
      
  } 
});
client.on('message', msg => {
  if (!msg.content.startsWith(prefix)) return;

  const args = msg.content.trim().split(/ +/g);
  const cmd = args[0].slice(prefix.length).toLowerCase(); // case INsensitive, without prefix

  if (cmd === 'randnum') {
    if (args[1] == 'int'){
      var num = parseInt(args[2]);
      var integerstor = Math.floor(Math.random() * num);
      var fullstr = integerstor.toString();
      console.log(fullstr)
      const randint = new Discord.MessageEmbed()
      .setColor('#000DFF')
      .setTitle("Randnum 3.1")
      .setDescription('A random number generator that is easy to use!')
      .addFields(
        {name: `Your random integer is: `, value: `${fullstr}`}
      )
      .setFooter("2020 Firey Inc/2020 Power RnD")
      msg.channel.send(randint)
  
    }
    if (args[1] == 'flt'){
      var num = parseInt(args[2]);
      var integerstor = Math.random() * num;
      var fullstr = integerstor.toString();
      console.log(fullstr)
      const randint = new Discord.MessageEmbed()
      .setColor('#000DFF')
      .setTitle("RandNum 3.1")
      .setDescription('A random integer generator that is easy to use!')
      .addFields(
        {name: `Your random integer is: `, value: `${fullstr}`}
      )
      .setFooter("2020 Firey Inc/2020 Power RnD")
      msg.channel.send(randint)
  
    }
  }
});



client.on('message', message => {
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.trim().split(/\s*(?:;|$)\s*/);
  const cmd = args[0].slice(prefix.length).toLowerCase(); // case INsensitive, without prefix

  if (cmd === 'doihaverole') {
    adminrole = message.member.roles.cache.find(role => role.name == `${args[1]}`);
     if(adminrole != null){memberIsAdmin = true;}else{memberIsAdmin = false;}

    if (memberIsAdmin == true){
      message.channel.send('You have this role!')
    }
    if (memberIsAdmin == false){
      message.channel.send('You do not have this role.')
    }
    
  }  
});






client.login('token');