#!/bin/zsh
node index.js